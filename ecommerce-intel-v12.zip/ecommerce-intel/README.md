# E-commerce Competitive Intelligence Tool

A production-quality Python tool for analyzing independent e-commerce sites (Shopify, DTC sites) and generating actionable competitive intelligence for Chinese merchants selling cross-border (China → US).

## ✨ Features

### Core Features
- **Multi-platform detection**: Automatically identifies Shopify, WooCommerce, Magento, BigCommerce, Wix, Squarespace, and custom platforms
- **Comprehensive extraction**: Products, prices, promotions, policies, trust signals, and more
- **Chinese insights**: Generates actionable bullet points in Chinese (关键洞察)
- **Change detection**: Monitor mode tracks changes between scans
- **robots.txt compliance**: Respects website crawling policies by default

### 🤖 AI-Powered Analysis (NEW)
- **Qwen2.5 LLM**: Generate intelligent Chinese insights using local AI (via Ollama)
- **Pricing Prediction**: ML-based optimal pricing recommendations
- **Threat Scoring**: Automated competitor threat assessment (1-10 scale)
- **Competitive Positioning**: Deep analysis of brand positioning and strategy

## 🚀 Quick Start (Windows)

### One-Time Setup

```powershell
# 1. Extract the zip file and navigate to the folder
cd ecommerce-intel

# 2. Run setup (creates venv, installs dependencies)
.\setup.ps1

# Optional: Install with Playwright for JavaScript-heavy sites
.\setup.ps1 -InstallPlaywright
```

### Running the Tool

```powershell
# Basic run
.\run.ps1

# With AI-powered analysis (requires Ollama)
.\run.ps1 -AI

# With JavaScript rendering (for dynamic sites)
.\run.ps1 -RenderJS

# Full options
.\run.ps1 -AI -RenderJS -Verbose -Monitor
```

That's it! Reports are generated in the `output/` folder.

## 🤖 Enabling AI Analysis

AI analysis uses **Qwen2.5** running locally via **Ollama** (free, private, no API costs).

### Install Ollama

1. Download from: https://ollama.com/download
2. Install and run Ollama
3. Pull the Qwen2.5 model:

```powershell
ollama pull qwen2.5:7b
```

### Verify AI is Working

```powershell
# Check Ollama is running
ollama list

# Should show qwen2.5:7b in the list
```

### Run with AI

```powershell
.\run.ps1 -AI
```

## 📊 Output Format

### Markdown Report (`output/report.md`)

For each site:
- 🔍 **关键洞察** (Key Insights) - 6-12 AI-generated bullet points
- 💡 **可复制的动作建议** (Recommendations) - 3 actionable items
- ⚠️ **竞争威胁评估** (Threat Score) - 1-10 with explanation
- 💰 **定价策略建议** (Pricing Advice) - Optimal price recommendations
- 📋 **数据证据** (Evidence) - Links and extracted values
- 📈 **变化追踪** (Changes) - If monitor mode enabled

### Comparison Table

| 网站 | 平台 | 品牌定位 | 价格区间 | 促销手段 | 威胁评分 |
|------|------|----------|----------|----------|----------|
| example.com | Shopify | 配饰品牌 | $15-$50 | 弹窗、会员 | 7/10 |

## 🔧 Advanced Usage

### Command Line Options

```powershell
python main.py --help

Options:
  -s, --sites TEXT       Path to sites.txt file (required)
  -o, --outdir TEXT      Output directory [default: output]
  --render-js            Use Playwright for JS rendering
  --ignore-robots        Ignore robots.txt restrictions
  -t, --timeout INTEGER  Request timeout [default: 30]
  --max-products INTEGER Max products per site [default: 50]
  --max-pages INTEGER    Max pages per site [default: 20]
  -m, --monitor          Enable change detection
  --ai                   Enable AI analysis
  --ai-model TEXT        Ollama model [default: qwen2.5:7b]
  -v, --verbose          Verbose logging
```

### Using Different AI Models

```powershell
# Use larger Qwen model (requires more VRAM)
python main.py --sites sites.txt --ai --ai-model qwen2.5:14b

# Use DeepSeek (if available)
python main.py --sites sites.txt --ai --ai-model deepseek-v2
```

## Data Extracted

### Per Site

| Category | Data Points |
|----------|-------------|
| **Platform** | Shopify, WooCommerce, Magento, etc. |
| **Brand** | Name, positioning, meta description |
| **Products** | Titles, URLs, prices, categories |
| **Pricing** | Min/max/median, currency, discounts |
| **Promotions** | Announcement bars, popups, email capture |
| **Programs** | Loyalty, referral, subscriptions, bundles |
| **Shipping** | Free threshold, regions, delivery times |
| **Returns** | Days, free returns, conditions |
| **Trust** | Reviews (platform + count), badges, payments |
| **Analytics** | GA, Meta Pixel, TikTok, Klaviyo |

## Architecture

```
ecommerce-intel/
├── main.py                 # CLI entry point
├── modules/
│   ├── __init__.py
│   ├── models.py           # Data models (dataclasses)
│   ├── http_client.py      # HTTP with rate limiting
│   ├── robots_checker.py   # robots.txt compliance
│   ├── url_utils.py        # URL normalization
│   ├── platform_detector.py # Platform detection
│   ├── page_discovery.py   # Sitemap/link crawling
│   ├── product_extractor.py # Product extraction
│   ├── promo_extractor.py  # Promotion detection
│   ├── policy_extractor.py # Policy extraction
│   ├── trust_extractor.py  # Trust signals
│   ├── snapshot_store.py   # SQLite caching
│   ├── insight_generator.py # Chinese insights
│   └── report_writer.py    # Report generation
├── data/                   # SQLite cache
├── output/                 # Generated reports
├── requirements.txt
├── config.example.yaml
├── sites.txt
└── README.md
```

## Extending the Tool

### Adding New Extractors

1. Create a new module in `modules/`:

```python
# modules/my_extractor.py
from bs4 import BeautifulSoup

def extract_my_data(soup: BeautifulSoup, html_str: str) -> dict:
    # Your extraction logic
    return {'key': 'value'}
```

2. Import in `modules/__init__.py`
3. Call from `main.py` in the `analyze_site()` function

### Adding New Platforms

Edit `modules/platform_detector.py` and add patterns:

```python
Platform.NEW_PLATFORM: {
    'html': [r'pattern1', r'pattern2'],
    'scripts': [r'script_pattern'],
    'headers': [('x-header-name', '')],
    'meta': [('generator', r'platform_name', False)],
}
```

### Custom Insights

Edit `modules/insight_generator.py` to customize:
- Chinese bullet point generation
- Recommendation logic
- Price tier classification

## Limitations

1. **Dynamic content**: Some sites require JavaScript rendering (`--render-js`)
2. **Anti-bot protection**: Sites with aggressive protection may block requests
3. **Login walls**: Cannot access content behind authentication
4. **CAPTCHAs**: Not bypassed (returns "无法获取")
5. **Rate limits**: Respects 1.5s delay between requests

## Ethical Usage

- **Respect robots.txt** by default
- **Rate limiting** prevents server overload
- **No login bypass** - only public content
- **No CAPTCHA solving** - marks blocked content
- Use for competitive intelligence only

## Troubleshooting

### Common Issues

**SSL Errors**:
```
SSL error for https://example.com
```
The tool automatically retries without SSL verification.

**403 Forbidden**:
```
Access forbidden (403)
```
Site is blocking automated requests. Try `--render-js` or check robots.txt.

**Timeout**:
```
Timeout after 30s
```
Increase timeout: `--timeout 60`

**No products found**:
Site may use heavy JavaScript. Try `--render-js`.

### Debug Mode

```bash
python main.py --sites sites.txt --verbose
```

## License

MIT License - See LICENSE file.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new features
4. Submit a pull request

## Changelog

### v1.0.0
- Initial release
- Multi-platform detection
- Chinese insight generation
- Change detection (monitor mode)
- Markdown and CSV reports
