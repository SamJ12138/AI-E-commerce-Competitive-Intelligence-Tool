"""
report_writer.py - Generate Markdown and CSV reports.

Creates:
- Per-site Chinese insights in Markdown
- Consolidated comparison table
- CSV export
"""

import csv
import logging
from typing import List, Dict, Optional
from pathlib import Path
from datetime import datetime

from .models import SiteIntelligence, ChangeReport
from .insight_generator import generate_insights, format_changes_zh

logger = logging.getLogger(__name__)


class ReportWriter:
    """
    Generates Markdown and CSV reports from site intelligence.
    """
    
    def __init__(self, output_dir: str = "output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def write_full_report(
        self,
        intel_list: List[SiteIntelligence],
        changes: Dict[str, Optional[ChangeReport]],
        report_name: str = "report"
    ) -> tuple:
        """
        Write complete Markdown and CSV reports.
        
        Args:
            intel_list: List of SiteIntelligence objects
            changes: Dict mapping domain to ChangeReport (or None)
            report_name: Base name for output files
            
        Returns:
            Tuple of (markdown_path, csv_path)
        """
        md_path = self.output_dir / f"{report_name}.md"
        csv_path = self.output_dir / f"{report_name}.csv"
        
        # Generate Markdown
        md_content = self._generate_markdown(intel_list, changes)
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write(md_content)
        
        logger.info(f"Wrote Markdown report to {md_path}")
        
        # Generate CSV
        self._write_csv(intel_list, csv_path)
        logger.info(f"Wrote CSV report to {csv_path}")
        
        return str(md_path), str(csv_path)
    
    def _generate_markdown(
        self,
        intel_list: List[SiteIntelligence],
        changes: Dict[str, Optional[ChangeReport]]
    ) -> str:
        """Generate complete Markdown report."""
        lines = []
        
        # Header
        lines.append("# 跨境电商竞品情报报告")
        lines.append("")
        lines.append(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        lines.append(f"**分析站点数**: {len(intel_list)}")
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Per-site sections
        for intel in intel_list:
            lines.extend(self._generate_site_section(intel, changes.get(intel.domain)))
            lines.append("")
            lines.append("---")
            lines.append("")
        
        # Consolidated comparison table
        lines.append("## 📊 综合对比表")
        lines.append("")
        lines.extend(self._generate_comparison_table(intel_list))
        lines.append("")
        
        # Footer
        lines.append("---")
        lines.append("")
        lines.append("*报告由 E-commerce Intelligence Tool 自动生成*")
        
        return '\n'.join(lines)
    
    def _generate_site_section(
        self,
        intel: SiteIntelligence,
        change_report: Optional[ChangeReport]
    ) -> List[str]:
        """Generate Markdown section for a single site."""
        lines = []
        
        # Header
        lines.append(f"## 🏪 {intel.domain}")
        lines.append("")
        lines.append(f"**网址**: [{intel.url}]({intel.url})")
        lines.append(f"**平台**: {intel.platform.value}")
        lines.append("")
        
        # Check if AI insights are available
        has_ai = hasattr(intel, 'ai_insights') and intel.ai_insights
        
        if has_ai:
            lines.append("🤖 **AI-Powered Analysis** (Qwen2.5)")
            lines.append("")
        
        # Generate insights (AI or rule-based)
        if has_ai and intel.ai_insights.get('key_insights'):
            # Use AI-generated insights
            lines.append("### 🔍 关键洞察 (AI分析)")
            lines.append("")
            for insight in intel.ai_insights.get('key_insights', [])[:12]:
                lines.append(f"- {insight}")
            lines.append("")
            
            # AI recommendations
            if intel.ai_insights.get('recommendations'):
                lines.append("### 💡 可复制的动作建议 (AI推荐)")
                lines.append("")
                for i, rec in enumerate(intel.ai_insights.get('recommendations', [])[:3], 1):
                    lines.append(f"{i}. {rec}")
                lines.append("")
            
            # AI threat analysis
            if hasattr(intel, 'ai_threat') and intel.ai_threat:
                lines.append("### ⚠️ 竞争威胁评估")
                lines.append("")
                threat = intel.ai_threat
                lines.append(f"**威胁评分**: {threat.get('score', 'N/A')}/10")
                lines.append("")
                if threat.get('explanation'):
                    for line in threat['explanation'].split('\n'):
                        if line.strip():
                            lines.append(f"- {line.strip()}")
                lines.append("")
            
            # AI pricing advice
            if hasattr(intel, 'ai_pricing') and intel.ai_pricing:
                lines.append("### 💰 定价策略建议")
                lines.append("")
                pricing = intel.ai_pricing
                lines.append(f"- 竞品中位价: ${pricing.get('competitor_median', 0):.2f}")
                lines.append(f"- 建议低价位: ${pricing.get('recommended_low', 0):.2f}")
                lines.append(f"- 建议最优价: ${pricing.get('recommended_optimal', 0):.2f}")
                lines.append(f"- 建议高价位: ${pricing.get('recommended_high', 0):.2f}")
                lines.append("")
            
            # AI positioning analysis
            if hasattr(intel, 'ai_positioning') and intel.ai_positioning:
                lines.append("### 🎯 品牌定位分析")
                lines.append("")
                lines.append(intel.ai_positioning)
                lines.append("")
        else:
            # Fall back to rule-based insights
            insights = generate_insights(intel)
            
            # Key insights
            lines.append("### 🔍 关键洞察")
            lines.append("")
            for insight in insights['key_insights']:
                lines.append(f"- {insight}")
            lines.append("")
            
            # Recommendations
            lines.append("### 💡 可复制的动作建议")
            lines.append("")
            for i, rec in enumerate(insights['recommendations'], 1):
                lines.append(f"{i}. {rec}")
            lines.append("")
        
        # Evidence (always show)
        insights = generate_insights(intel)
        lines.append("### 📋 数据证据")
        lines.append("")
        for evidence in insights['evidence']:
            lines.append(f"- {evidence}")
        lines.append("")
        
        # Change tracking
        lines.append("### 📈 变化追踪")
        lines.append("")
        change_lines = format_changes_zh(change_report)
        for change in change_lines:
            lines.append(f"- {change}")
        lines.append("")
        
        # Products section (if available)
        if intel.hero_products:
            lines.append("### 🛒 热门产品示例")
            lines.append("")
            for product in intel.hero_products[:3]:
                price_str = f"${product.price.current_price:.2f}" if product.price and product.price.current_price else "价格未知"
                lines.append(f"- **{product.title}** - {price_str}")
            lines.append("")
        
        return lines
    
    def _generate_comparison_table(
        self,
        intel_list: List[SiteIntelligence]
    ) -> List[str]:
        """Generate consolidated comparison Markdown table."""
        lines = []
        
        # Table header
        headers = [
            "网站", "平台", "品牌定位", "主打品类", "价格区间",
            "促销手段", "运费/免邮", "退换货", "信任要素", "关键可复制点"
        ]
        
        lines.append("| " + " | ".join(headers) + " |")
        lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
        
        # Table rows
        for intel in intel_list:
            row = self._generate_table_row(intel)
            lines.append("| " + " | ".join(row) + " |")
        
        return lines
    
    def _generate_table_row(self, intel: SiteIntelligence) -> List[str]:
        """Generate a single table row for a site."""
        # Website
        website = intel.domain
        
        # Platform
        platform = intel.platform.value.split('/')[0]  # Just first word
        
        # Brand positioning
        positioning = intel.brand_description_zh[:30] if intel.brand_description_zh else "无明确信息"
        
        # Categories
        categories = '、'.join(intel.categories[:2]) if intel.categories else "无明确信息"
        if len(categories) > 25:
            categories = categories[:25] + "..."
        
        # Price range
        if intel.price_min and intel.price_max:
            price_range = f"${intel.price_min:.0f}-${intel.price_max:.0f}"
        else:
            price_range = "无明确信息"
        
        # Promotions
        promos = []
        if intel.has_popup:
            promos.append("弹窗")
        if intel.has_email_capture:
            promos.append("邮件订阅")
        if intel.has_loyalty_program:
            promos.append("会员")
        if intel.announcement_bar_text:
            promos.append("公告栏")
        promotions = '、'.join(promos[:3]) if promos else "无"
        
        # Shipping
        if intel.shipping_policy:
            ship = intel.shipping_policy
            if ship.free_shipping_threshold is not None:
                if ship.free_shipping_threshold == 0:
                    shipping = "全场免运费"
                else:
                    shipping = f"满${ship.free_shipping_threshold:.0f}免运费"
            else:
                shipping = "有运费"
        else:
            shipping = "无明确信息"
        
        # Returns
        if intel.return_policy and intel.return_policy.return_days:
            ret = intel.return_policy
            returns = f"{ret.return_days}天"
            if ret.free_returns:
                returns += "(免费)"
        else:
            returns = "无明确信息"
        
        # Trust signals
        trust = []
        if intel.review_platform:
            trust.append("评论")
        bnpl = [m for m in intel.payment_methods if m in ['Klarna', 'Afterpay', 'Affirm']]
        if bnpl:
            trust.append("分期付款")
        if any(s.signal_type == 'badge' for s in intel.trust_signals):
            trust.append("信任徽章")
        trust_str = '、'.join(trust[:2]) if trust else "无"
        
        # Key replicable point
        key_point = "无"
        if intel.has_subscriptions:
            key_point = "订阅模式"
        elif intel.has_bundles:
            key_point = "捆绑销售"
        elif intel.shipping_policy and intel.shipping_policy.free_shipping_threshold == 0:
            key_point = "免运费策略"
        elif intel.has_loyalty_program:
            key_point = "会员体系"
        elif intel.review_platform:
            key_point = "评论系统"
        
        return [
            website, platform, positioning, categories, price_range,
            promotions, shipping, returns, trust_str, key_point
        ]
    
    def _write_csv(
        self,
        intel_list: List[SiteIntelligence],
        csv_path: Path
    ) -> None:
        """Write CSV export of the comparison table."""
        headers = [
            "domain", "url", "platform", "brand_positioning",
            "categories", "price_min", "price_max", "price_median",
            "currency", "has_discounts", "announcement_bar",
            "has_popup", "has_email_capture", "has_loyalty",
            "has_referral", "free_shipping_threshold",
            "return_days", "free_returns", "review_platform",
            "review_count", "payment_methods", "pixels_detected",
            "scan_timestamp"
        ]
        
        with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            
            for intel in intel_list:
                row = {
                    "domain": intel.domain,
                    "url": intel.url,
                    "platform": intel.platform.value,
                    "brand_positioning": intel.brand_description_zh or intel.meta_description[:100],
                    "categories": "; ".join(intel.categories),
                    "price_min": intel.price_min,
                    "price_max": intel.price_max,
                    "price_median": intel.price_median,
                    "currency": intel.currency,
                    "has_discounts": intel.has_discounts,
                    "announcement_bar": intel.announcement_bar_text[:100] if intel.announcement_bar_text else "",
                    "has_popup": intel.has_popup,
                    "has_email_capture": intel.has_email_capture,
                    "has_loyalty": intel.has_loyalty_program,
                    "has_referral": intel.has_referral_program,
                    "free_shipping_threshold": intel.shipping_policy.free_shipping_threshold if intel.shipping_policy else None,
                    "return_days": intel.return_policy.return_days if intel.return_policy else None,
                    "free_returns": intel.return_policy.free_returns if intel.return_policy else None,
                    "review_platform": intel.review_platform,
                    "review_count": intel.total_reviews,
                    "payment_methods": "; ".join(intel.payment_methods),
                    "pixels_detected": "; ".join(p.name for p in intel.pixels if p.detected),
                    "scan_timestamp": intel.scan_timestamp.isoformat()
                }
                writer.writerow(row)


def write_markdown_report(
    intel_list: List[SiteIntelligence],
    changes: Dict[str, Optional[ChangeReport]],
    output_dir: str = "output"
) -> str:
    """
    Convenience function to write Markdown report.
    
    Args:
        intel_list: List of SiteIntelligence objects
        changes: Dict of domain to ChangeReport
        output_dir: Output directory
        
    Returns:
        Path to generated report
    """
    writer = ReportWriter(output_dir)
    md_path, _ = writer.write_full_report(intel_list, changes)
    return md_path


def write_csv(
    intel_list: List[SiteIntelligence],
    output_dir: str = "output"
) -> str:
    """
    Convenience function to write CSV report.
    
    Args:
        intel_list: List of SiteIntelligence objects
        output_dir: Output directory
        
    Returns:
        Path to generated CSV
    """
    writer = ReportWriter(output_dir)
    _, csv_path = writer.write_full_report(intel_list, {})
    return csv_path
