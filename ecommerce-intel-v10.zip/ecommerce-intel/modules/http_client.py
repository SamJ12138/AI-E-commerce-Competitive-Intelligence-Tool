"""
http_client.py - HTTP client with rate limiting, retries, and error handling.

Provides a robust HTTP client that respects rate limits, handles common errors,
and optionally supports JavaScript rendering via Playwright.
"""

import time
import logging
from typing import Optional, Dict, Any, Tuple
from urllib.parse import urlparse, urljoin
import ssl
import warnings

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

from .models import Config

logger = logging.getLogger(__name__)


class RateLimiter:
    """Simple per-domain rate limiter."""
    
    def __init__(self, delay: float = 1.5):
        self.delay = delay
        self.last_request: Dict[str, float] = {}
    
    def wait(self, domain: str) -> None:
        """Wait if necessary before making a request to the domain."""
        now = time.time()
        if domain in self.last_request:
            elapsed = now - self.last_request[domain]
            if elapsed < self.delay:
                sleep_time = self.delay - elapsed
                logger.debug(f"Rate limiting: sleeping {sleep_time:.2f}s for {domain}")
                time.sleep(sleep_time)
        self.last_request[domain] = time.time()


class HttpClient:
    """
    HTTP client with robust error handling and optional JS rendering.
    
    Features:
    - Automatic retries with exponential backoff
    - Rate limiting per domain
    - Custom headers to avoid bot detection
    - SSL error handling
    - Optional JavaScript rendering via Playwright
    """
    
    def __init__(self, config: Config):
        self.config = config
        self.rate_limiter = RateLimiter(config.rate_limit_delay)
        self.session = self._create_session()
        self._playwright = None
        self._browser = None
        self._context = None
    
    def _create_session(self) -> requests.Session:
        """Create a requests session with retry logic."""
        session = requests.Session()
        
        # Configure retries
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Set default headers
        session.headers.update({
            "User-Agent": self.config.user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        })
        
        return session
    
    def _init_playwright(self) -> None:
        """Initialize Playwright browser (lazy loading)."""
        if not PLAYWRIGHT_AVAILABLE:
            raise RuntimeError(
                "Playwright is not installed. Install with: "
                "pip install playwright && playwright install chromium"
            )
        
        if self._playwright is None:
            self._playwright = sync_playwright().start()
            self._browser = self._playwright.chromium.launch(
                headless=True,
                args=[
                    '--disable-blink-features=AutomationControlled',
                    '--disable-dev-shm-usage',
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-web-security',
                    '--disable-features=IsolateOrigins,site-per-process',
                ]
            )
            self._context = self._browser.new_context(
                user_agent=self.config.user_agent,
                viewport={"width": 1920, "height": 1080},
                java_script_enabled=True,
                bypass_csp=True,
                ignore_https_errors=True,
            )
            # Add script to mask automation
            self._context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            """)
            logger.info("Playwright browser initialized")
    
    def close(self) -> None:
        """Clean up resources."""
        if self._context:
            self._context.close()
        if self._browser:
            self._browser.close()
        if self._playwright:
            self._playwright.stop()
        self.session.close()
    
    def fetch(
        self,
        url: str,
        render_js: Optional[bool] = None
    ) -> Tuple[Optional[str], int, Dict[str, str], Optional[str]]:
        """
        Fetch a URL and return (html_content, status_code, headers, error).
        
        Args:
            url: URL to fetch
            render_js: Override config.render_js for this request
        
        Returns:
            Tuple of (html_content, status_code, response_headers, error_message)
            If error, html_content will be None and error_message will be set.
        """
        use_js = render_js if render_js is not None else self.config.render_js
        parsed = urlparse(url)
        domain = parsed.netloc
        
        # Apply rate limiting
        self.rate_limiter.wait(domain)
        
        if use_js:
            return self._fetch_with_playwright(url)
        else:
            return self._fetch_with_requests(url)
    
    def _fetch_with_requests(
        self,
        url: str
    ) -> Tuple[Optional[str], int, Dict[str, str], Optional[str]]:
        """Fetch using requests library."""
        try:
            # Suppress SSL warnings for self-signed certs
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                response = self.session.get(
                    url,
                    timeout=self.config.timeout,
                    verify=True,  # Will retry with verify=False if needed
                    allow_redirects=True
                )
            
            headers = dict(response.headers)
            
            # Check for common blocks
            if response.status_code == 403:
                return None, 403, headers, "Access forbidden (403)"
            if response.status_code == 404:
                return None, 404, headers, "Page not found (404)"
            if response.status_code == 429:
                return None, 429, headers, "Rate limited (429)"
            
            response.raise_for_status()
            
            # Handle encoding
            response.encoding = response.apparent_encoding or 'utf-8'
            
            return response.text, response.status_code, headers, None
            
        except requests.exceptions.SSLError as e:
            logger.warning(f"SSL error for {url}, retrying without verification")
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    response = self.session.get(
                        url,
                        timeout=self.config.timeout,
                        verify=False,
                        allow_redirects=True
                    )
                return response.text, response.status_code, dict(response.headers), None
            except Exception as e2:
                return None, 0, {}, f"SSL error: {str(e2)}"
                
        except requests.exceptions.Timeout:
            return None, 0, {}, f"Timeout after {self.config.timeout}s"
            
        except requests.exceptions.ConnectionError as e:
            return None, 0, {}, f"Connection error: {str(e)}"
            
        except requests.exceptions.RequestException as e:
            return None, 0, {}, f"Request error: {str(e)}"
    
    def _fetch_with_playwright(
        self,
        url: str
    ) -> Tuple[Optional[str], int, Dict[str, str], Optional[str]]:
        """Fetch using Playwright for JavaScript rendering."""
        try:
            self._init_playwright()
            
            page = self._context.new_page()
            
            try:
                # Use longer timeout (60s) and domcontentloaded instead of networkidle
                # networkidle can hang on sites with continuous background requests
                response = page.goto(
                    url,
                    timeout=60000,  # 60 seconds
                    wait_until="domcontentloaded"
                )
                
                # Wait for common content indicators
                try:
                    # Try to wait for main content to appear
                    page.wait_for_selector('body', timeout=5000)
                    # Additional wait for dynamic content
                    page.wait_for_timeout(3000)
                except:
                    # If selector wait fails, just continue
                    page.wait_for_timeout(2000)
                
                status = response.status if response else 200
                headers = dict(response.headers) if response else {}
                
                # Get the rendered HTML
                html = page.content()
                
                return html, status, headers, None
                
            finally:
                page.close()
                
        except PlaywrightTimeout:
            return None, 0, {}, f"Playwright timeout after 60s"
        except Exception as e:
            return None, 0, {}, f"Playwright error: {str(e)}"
    
    def fetch_and_parse(
        self,
        url: str,
        render_js: Optional[bool] = None
    ) -> Tuple[Optional[BeautifulSoup], int, Optional[str]]:
        """
        Fetch URL and return parsed BeautifulSoup object.
        
        Returns:
            Tuple of (soup, status_code, error_message)
        """
        html, status, headers, error = self.fetch(url, render_js)
        
        if error:
            return None, status, error
        
        if not html:
            return None, status, "Empty response"
        
        try:
            # Use lxml for speed, fall back to html.parser
            try:
                soup = BeautifulSoup(html, 'lxml')
            except Exception:
                soup = BeautifulSoup(html, 'html.parser')
            
            return soup, status, None
            
        except Exception as e:
            return None, status, f"HTML parsing error: {str(e)}"
    
    def head(self, url: str) -> Tuple[int, Dict[str, str], Optional[str]]:
        """
        Make a HEAD request to check URL status.
        
        Returns:
            Tuple of (status_code, headers, error_message)
        """
        parsed = urlparse(url)
        self.rate_limiter.wait(parsed.netloc)
        
        try:
            response = self.session.head(
                url,
                timeout=self.config.timeout,
                allow_redirects=True
            )
            return response.status_code, dict(response.headers), None
        except Exception as e:
            return 0, {}, str(e)
