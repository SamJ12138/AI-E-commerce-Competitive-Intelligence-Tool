"""
policy_extractor.py - Extract shipping and return policies from e-commerce pages.

Extracts structured information from policy pages:
- Shipping regions and delivery times
- Free shipping thresholds
- Return windows and conditions
- Refund policies
"""

import re
import logging
from typing import Optional, List, Tuple
from bs4 import BeautifulSoup

from .models import ShippingPolicy, ReturnPolicy

logger = logging.getLogger(__name__)


class PolicyExtractor:
    """
    Extracts structured policy information from e-commerce pages.
    """
    
    # Shipping time patterns
    SHIPPING_TIME_PATTERNS = [
        r'(\d+)\s*[-–to]+\s*(\d+)\s*(business\s+)?(days?|weeks?)',
        r'within\s+(\d+)\s*(business\s+)?(days?|weeks?)',
        r'(\d+)\s*(business\s+)?(days?|weeks?)\s+delivery',
        r'ships?\s+in\s+(\d+)\s*[-–to]*\s*(\d*)\s*(business\s+)?(days?)',
        r'delivery\s+time[:\s]+(\d+)\s*[-–to]*\s*(\d*)\s*(days?)',
    ]
    
    # Free shipping patterns
    FREE_SHIPPING_PATTERNS = [
        r'free\s+(standard\s+)?shipping\s+(on\s+)?orders?\s+(over\s+)?\$(\d+)',
        r'free\s+shipping\s+for\s+orders?\s+\$(\d+)\+',
        r'\$(\d+)\s+(or\s+more\s+)?for\s+free\s+shipping',
        r'spend\s+\$(\d+).*free\s+shipping',
        r'free\s+shipping\s+on\s+all\s+orders',
    ]
    
    # Return days patterns
    RETURN_DAYS_PATTERNS = [
        r'(\d+)\s*[-–]?\s*days?\s+(return|exchange|refund)',
        r'return\s+(within\s+)?(\d+)\s*days?',
        r'(\d+)\s*[-–]?\s*day\s+return\s+policy',
        r'returns?\s+accepted\s+(within\s+)?(\d+)\s*days?',
        r'(\d+)\s*[-–]?\s*day\s+money[- ]back',
    ]
    
    # Region patterns
    REGION_PATTERNS = {
        'United States': [r'united\s+states', r'\bUS\b', r'\bUSA\b', r'domestic'],
        'Canada': [r'\bcanada\b', r'\bCA\b'],
        'International': [r'international', r'worldwide', r'global'],
        'Europe': [r'\beurope\b', r'\bEU\b', r'european'],
        'UK': [r'\buk\b', r'united\s+kingdom', r'britain'],
        'Australia': [r'\baustralia\b', r'\bAU\b'],
    }
    
    def extract_shipping_policy(
        self,
        soup: BeautifulSoup,
        page_text: str
    ) -> ShippingPolicy:
        """
        Extract shipping policy information.
        
        Args:
            soup: Parsed HTML of policy page
            page_text: Raw text content of the page
            
        Returns:
            ShippingPolicy object
        """
        policy = ShippingPolicy()
        text_lower = page_text.lower()
        
        # Extract shipping regions
        policy.regions = self._extract_regions(text_lower)
        
        # Extract free shipping threshold
        policy.free_shipping_threshold = self._extract_free_shipping_threshold(text_lower)
        
        # Extract delivery times
        min_days, max_days = self._extract_delivery_times(text_lower)
        policy.estimated_days_min = min_days
        policy.estimated_days_max = max_days
        
        # Check for international shipping
        policy.has_international = 'international' in text_lower or 'worldwide' in text_lower
        
        # Store raw text for reference
        policy.raw_text = page_text[:2000]  # First 2000 chars
        
        return policy
    
    def extract_return_policy(
        self,
        soup: BeautifulSoup,
        page_text: str
    ) -> ReturnPolicy:
        """
        Extract return policy information.
        
        Args:
            soup: Parsed HTML of policy page
            page_text: Raw text content of the page
            
        Returns:
            ReturnPolicy object
        """
        policy = ReturnPolicy()
        text_lower = page_text.lower()
        
        # Extract return window
        policy.return_days = self._extract_return_days(text_lower)
        
        # Check for free returns
        policy.free_returns = self._check_free_returns(text_lower)
        
        # Extract conditions
        policy.conditions = self._extract_return_conditions(text_lower)
        
        # Extract exclusions
        policy.exclusions = self._extract_exclusions(text_lower)
        
        # Store raw text
        policy.raw_text = page_text[:2000]
        
        return policy
    
    def _extract_regions(self, text: str) -> List[str]:
        """Extract shipping regions mentioned."""
        regions = []
        
        for region, patterns in self.REGION_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    regions.append(region)
                    break
        
        return list(set(regions)) if regions else ['United States']
    
    def _extract_free_shipping_threshold(self, text: str) -> Optional[float]:
        """Extract free shipping threshold amount."""
        for pattern in self.FREE_SHIPPING_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                # Find the numeric group
                for group in match.groups():
                    if group and group.isdigit():
                        return float(group)
        
        # Check for "free shipping on all orders"
        if re.search(r'free\s+shipping\s+on\s+all\s+orders', text, re.IGNORECASE):
            return 0.0
        
        return None
    
    def _extract_delivery_times(self, text: str) -> Tuple[Optional[int], Optional[int]]:
        """Extract estimated delivery time range."""
        for pattern in self.SHIPPING_TIME_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                groups = [g for g in match.groups() if g and g.isdigit()]
                
                if len(groups) >= 2:
                    return int(groups[0]), int(groups[1])
                elif len(groups) == 1:
                    days = int(groups[0])
                    return days, days
        
        return None, None
    
    def _extract_return_days(self, text: str) -> Optional[int]:
        """Extract return window in days."""
        for pattern in self.RETURN_DAYS_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                for group in match.groups():
                    if group and group.isdigit():
                        return int(group)
        
        return None
    
    def _check_free_returns(self, text: str) -> bool:
        """Check if returns are free."""
        free_return_patterns = [
            r'free\s+returns?',
            r'returns?\s+are\s+free',
            r'no\s+cost\s+returns?',
            r'complimentary\s+returns?',
            r'we\s+cover\s+return\s+shipping',
        ]
        
        for pattern in free_return_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        
        return False
    
    def _extract_return_conditions(self, text: str) -> List[str]:
        """Extract return conditions."""
        conditions = []
        
        condition_patterns = [
            (r'unworn', 'Items must be unworn'),
            (r'original\s+(packaging|tags)', 'Original packaging/tags required'),
            (r'unused', 'Items must be unused'),
            (r'unwashed', 'Items must be unwashed'),
            (r'receipt', 'Receipt required'),
            (r'proof\s+of\s+purchase', 'Proof of purchase required'),
            (r'original\s+condition', 'Items must be in original condition'),
        ]
        
        for pattern, condition in condition_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                conditions.append(condition)
        
        return conditions[:5]  # Limit to 5 conditions
    
    def _extract_exclusions(self, text: str) -> List[str]:
        """Extract items excluded from returns."""
        exclusions = []
        
        exclusion_patterns = [
            (r'final\s+sale', 'Final sale items'),
            (r'sale\s+items?\s+(are\s+)?not\s+returnable', 'Sale items'),
            (r'undergarments?', 'Undergarments'),
            (r'swimwear', 'Swimwear'),
            (r'intimate', 'Intimate items'),
            (r'personalized', 'Personalized items'),
            (r'customized', 'Customized items'),
            (r'gift\s+cards?', 'Gift cards'),
            (r'clearance', 'Clearance items'),
            (r'hygiene', 'Hygiene products'),
        ]
        
        for pattern, exclusion in exclusion_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                exclusions.append(exclusion)
        
        return list(set(exclusions))[:5]
    
    def extract_policy_links_from_footer(
        self,
        soup: BeautifulSoup,
        base_url: str
    ) -> dict:
        """
        Extract policy page links from footer.
        
        Many sites like Rastaclat have policy links in the footer:
        - /pages/return-policy
        - /policies/shipping-policy
        - /pages/faq
        
        Args:
            soup: Parsed HTML
            base_url: Base URL for making absolute URLs
            
        Returns:
            Dictionary with discovered policy URLs
        """
        from .url_utils import make_absolute_url
        
        policy_links = {
            'return_policy_url': None,
            'shipping_policy_url': None,
            'faq_url': None,
            'terms_url': None,
            'privacy_url': None,
        }
        
        # Look in footer first
        footer = soup.find('footer')
        search_area = footer if footer else soup
        
        # Find all links
        links = search_area.find_all('a', href=True)
        
        for link in links:
            href = link.get('href', '').lower()
            text = link.get_text(strip=True).lower()
            
            # Return/refund policy
            if any(kw in href or kw in text for kw in ['return', 'refund', 'exchange']):
                if 'policy' in href or 'policy' in text or '/pages/' in href:
                    policy_links['return_policy_url'] = make_absolute_url(base_url, link['href'])
            
            # Shipping policy
            if any(kw in href or kw in text for kw in ['shipping', 'delivery']):
                if 'policy' in href or 'policy' in text or '/pages/' in href or '/policies/' in href:
                    policy_links['shipping_policy_url'] = make_absolute_url(base_url, link['href'])
            
            # FAQ
            if 'faq' in href or 'faq' in text:
                policy_links['faq_url'] = make_absolute_url(base_url, link['href'])
            
            # Terms
            if 'terms' in href or 'terms' in text:
                policy_links['terms_url'] = make_absolute_url(base_url, link['href'])
            
            # Privacy
            if 'privacy' in href or 'privacy' in text:
                policy_links['privacy_url'] = make_absolute_url(base_url, link['href'])
        
        return policy_links


def extract_policies(
    soup: BeautifulSoup,
    page_text: str,
    page_type: str
) -> Tuple[Optional[ShippingPolicy], Optional[ReturnPolicy]]:
    """
    Extract policies from a page.
    
    Args:
        soup: Parsed HTML
        page_text: Raw text content
        page_type: Type of page ('shipping', 'return', 'policy', etc.)
        
    Returns:
        Tuple of (ShippingPolicy, ReturnPolicy) - either may be None
    """
    extractor = PolicyExtractor()
    
    shipping = None
    returns = None
    
    text_lower = page_text.lower()
    
    # Determine what to extract based on page type and content
    has_shipping_content = any(word in text_lower for word in [
        'shipping', 'delivery', 'ship', 'transit'
    ])
    has_return_content = any(word in text_lower for word in [
        'return', 'refund', 'exchange', 'money back'
    ])
    
    if has_shipping_content or page_type == 'shipping':
        shipping = extractor.extract_shipping_policy(soup, page_text)
    
    if has_return_content or page_type == 'return':
        returns = extractor.extract_return_policy(soup, page_text)
    
    return shipping, returns
